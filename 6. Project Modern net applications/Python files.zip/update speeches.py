import requests
import json

# Configuration
url = "http://localhost:1337/api/Speeches"  # Update to your Strapi instance URL
headers = {
    "Authorization": "Bearer ca59d7d6c6f60157189e1d74396e4aeda2eaccd8c511080a2936cfe783b5a0fd87fb1d22ed998ff05d1ffce181e34d41d790d86da03fe5e6787f07ca6ae0fed7b12b0f12edfbe72fd10907f3f46604e939210304affcd46b19339fba32715eb226b0fc3f33fe5c3285b7aeff0b51747c0cf7ca5045c36efecc8bb846a54cfb97",  # Replace with your API token
    "Content-Type": "application/json"
}

# Load data from JSON file
with open('C:\\my-project\\akndocs\\speeches.json', 'r', encoding='utf-8') as f:
    speeches = json.load(f)

# Fetch existing data from Strapi with offset-based pagination
existing_speech_ids = set()
page = 1  # Start with the first offset value
page_size = 25  # Number of items to fetch per request

while True:
    # Append offset and pageSize query parameters
    response = requests.get(url, headers=headers, params = {"pagination[page]": page, "pagination[pageSize]": page_size})  # Use _start for offset and _limit for pageSize
    if response.status_code == 200:
        existing_speeches = response.json()["data"]
        
        if not existing_speeches:  # No more speeches, exit the loop
            break

        # Add the IDs to the set
        existing_speech_ids.update(speech["jsonid"] for speech in existing_speeches)

        page += 1  # Increase the offset by pageSize
    else:
        print(f"Failed to fetch existing speeches: {response.status_code}, {response.text}")
        break

# Upload only new speeches
for speech in speeches:
    if speech["jsonid"] not in existing_speech_ids:
        payload = {
            "data": {
                "jsonid": speech["jsonid"],  # Include the ID in the payload if required by Strapi
                "speaker": speech["speaker"],
                "content": speech["content"],
                "debate_section": speech["debate_section"],
                "debate_title": speech["debate_title"],
                "debate_date": speech["debate_date"],
            }
        }
        response = requests.post(url, json=payload, headers=headers)
        if response.status_code == 201:
            print(f"Successfully added: {speech['jsonid']}")
        else:
            print(f"Failed to add {speech['jsonid']}: {response.status_code}, {response.text}")
    else:
        print(f"Skipped (already exists): {speech['jsonid']}")