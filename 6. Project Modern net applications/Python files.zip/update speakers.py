# -*- coding: utf-8 -*-
"""
Created on Sat Dec  7 09:14:28 2024

@author: ppetr
"""

import requests

url = "http://localhost:1337/api/Speakers"  
headers = {
    "Authorization": "Bearer ca59d7d6c6f60157189e1d74396e4aeda2eaccd8c511080a2936cfe783b5a0fd87fb1d22ed998ff05d1ffce181e34d41d790d86da03fe5e6787f07ca6ae0fed7b12b0f12edfbe72fd10907f3f46604e939210304affcd46b19339fba32715eb226b0fc3f33fe5c3285b7aeff0b51747c0cf7ca5045c36efecc8bb846a54cfb97",  # Replace with your API token
    "Content-Type": "application/json"
}

import json
with open('C:\\my-project\\akndocs\\speakers.json', 'r', encoding='utf-8') as f:
    speakers = json.load(f)

for speaker in speakers:
    payload = {
        "data": {
            "name": speaker["name"],
            "wikidata_id": speaker["wikidata_id"]
        }
    }
    response = requests.post(url, json=payload, headers=headers)
    if response.status_code == 201:
        print(f"Successfully added: {speaker['name']}")
    else:
        print(f"Failed to add {speaker['name']}: {response.status_code}, {response.text}")
