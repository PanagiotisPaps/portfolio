import os
import xml.etree.ElementTree as ET
import unicodedata
import json


def remove_accents(name):
    return ''.join(c for c in unicodedata.normalize('NFD', name) if unicodedata.category(c) != 'Mn')


def normalize_name(name):
    name = name.replace('-', ' ')
    name = remove_accents(name)
    return name.upper()


def parse_tei(file_path, seen_names, speaker_counter, speech_counter):
    tree = ET.parse(file_path)
    root = tree.getroot()
    namespace = {'tei': 'http://www.tei-c.org/ns/1.0'}
    speakers = []
    speeches = []

    speaker_map = {}  
    for person in root.findall('.//tei:person', namespace):
        name = person.find('tei:persName', namespace)
        wikidata_id = person.find('tei:idno[@type="AKN"]', namespace)
        speaker_name = name.text if name is not None else "Unknown"
        speaker_id = person.attrib.get(
            '{http://www.w3.org/XML/1998/namespace}id', "Unknown")

        if speaker_id not in seen_names:
            speakers.append({
                "id": speaker_counter,  
                "name": normalize_name(speaker_name),
                "wikidata_id": wikidata_id.text if wikidata_id is not None else None,
                "source_file": os.path.basename(file_path)
            })
            seen_names[speaker_id] = speaker_name
            speaker_counter += 1
        speaker_map[speaker_id] = speaker_name  
    
    for div in root.findall('.//tei:div[@type="debateSection"]', namespace):
        debate_section = div.attrib.get('subtype', "Unknown")
        debate_name_element = root.find(
            './/tei:div[@type="preface"]', namespace)
        debate_name = ""
        if debate_name_element is not None:
            paragraphs = debate_name_element.findall('tei:p', namespace)
            debate_name = ", ".join(p.text.strip()
                                    for p in paragraphs if p.text)
        debate_date = root.find(
            './/tei:profileDesc/tei:settingDesc/tei:setting/tei:date', namespace)
        date_value = debate_date.attrib.get(
            'when', "Unknown") if debate_date is not None else "Unknown"

        for speech in div.findall('.//tei:u', namespace):
            speaker_ref = speech.attrib.get('who', "").lstrip("#")
            speaker_name = speaker_map.get(speaker_ref, "Unknown")
            speech_text = " ".join(seg.text for seg in speech.findall(
                'tei:seg', namespace) if seg.text)
            speeches.append({
                "jsonid": speech_counter,  
                "speaker": normalize_name(speaker_name),
                "content": speech_text,
                "debate_section": debate_section,
                "debate_date": date_value,
                "debate_title": debate_name,
                "source_file": os.path.basename(file_path)
            })
            speech_counter += 1

    return speakers, speeches, speaker_counter, speech_counter


def parse_legaldocml(file_path, seen_names, speaker_counter, speech_counter):
    tree = ET.parse(file_path)
    root = tree.getroot()
    namespace = {'akn': 'http://docs.oasis-open.org/legaldocml/ns/akn/3.0'}
    speakers = []
    speeches = []

    debate_meta = root.find('.//akn:FRBRWork', namespace)
    debate_date = debate_meta.find('akn:FRBRdate[@name="Generation"]', namespace).attrib.get(
        'date', "Unknown") if debate_meta is not None else "Unknown"
    debate_title = debate_meta.find('akn:FRBRalias[@name="title"]', namespace).attrib.get(
        'value', "Unknown") if debate_meta is not None else "Unknown"

    speaker_map = {}  
    for person in root.findall('.//akn:TLCPerson', namespace):
        name = person.attrib.get('showAs', "Unknown")
        wikidata_id = person.attrib.get('href', None)
        speaker_id = person.attrib.get('eId', "Unknown")

        if speaker_id not in seen_names:
            speakers.append({
                "id": speaker_counter,  
                "name": normalize_name(name),
                "wikidata_id": wikidata_id,
                "source_file": os.path.basename(file_path)
            })
            seen_names[speaker_id] = name
            speaker_counter += 1
        speaker_map[speaker_id] = name  

    for debate_section in root.findall('.//akn:debateSection', namespace):
        section_name = debate_section.attrib.get('name', "Unknown")
        for speech in debate_section.findall('akn:speech', namespace):
            speaker_ref = speech.attrib.get('by', "Unknown")
            speaker_name = speaker_map.get(speaker_ref, "Unknown")
            speech_text = " ".join(p.text for p in speech.findall(
                'akn:p', namespace) if p.text)
            speeches.append({
                "jsonid": speech_counter,  # Use simple counter as ID
                "speaker": normalize_name(speaker_name),
                "content": speech_text,
                "debate_section": section_name,
                "debate_date": debate_date,
                "debate_title": debate_title,
                "source_file": os.path.basename(file_path)
            })
            speech_counter += 1

    return speakers, speeches, speaker_counter, speech_counter


def parse_directory(directory_path):
    all_speakers = []
    all_speeches = []
    seen_names = {}
    speaker_counter = 1  
    speech_counter = 1 

    for file_name in os.listdir(directory_path):
        if file_name.endswith(".xml"):
            file_path = os.path.join(directory_path, file_name)
            try:
                if "tei" in file_name.lower():
                    speakers, speeches, speaker_counter, speech_counter = parse_tei(file_path, seen_names, speaker_counter, speech_counter)
                elif "legaldocml" in file_name.lower() or "akn" in file_name.lower():
                    speakers, speeches, speaker_counter, speech_counter = parse_legaldocml(file_path, seen_names, speaker_counter, speech_counter)
                else:
                    continue

                all_speakers.extend(speakers)
                all_speeches.extend(speeches)

            except Exception as e:
                print(f"Error processing {file_name}: {e}")

    return all_speakers, all_speeches

directory_path = r'C:\my-project\akndocs'

speakers_data, speeches_data = parse_directory(directory_path)

output_speakers_file = os.path.join(directory_path, 'speakers.json')
output_speeches_file = os.path.join(directory_path, 'speeches.json')

with open(output_speakers_file, 'w', encoding='utf-8') as f:
    json.dump(speakers_data, f, ensure_ascii=False, indent=2)

with open(output_speeches_file, 'w', encoding='utf-8') as f:
    json.dump(speeches_data, f, ensure_ascii=False, indent=2)

print(f"Speakers saved to {output_speakers_file}")
print(f"Speeches saved to {output_speeches_file}")
