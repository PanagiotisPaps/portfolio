import requests

# Fetch all speakers data from Strapi


def get_speakers():
    response = requests.get('http://localhost:1337/api/Speeches/api/Speakers')
    speakers_data = response.json().get('data', [])
    return speakers_data

# Fetch speeches data based on a debate title


def get_speeches(debate_title):
    response = requests.get(
        f'http://localhost:1337/api/Speeches/api/Speeches?debate_title_contains={debate_title}')
    speeches_data = response.json().get('data', [])
    return speeches_data

# Fetch speeches by a specific speaker


def get_speeches_for_speaker(speaker_name):
    response = requests.get(
        f'http://localhost:1337/api/Speeches/api/Speeches?speaker={speaker_name}')
    speeches_data = response.json().get('data', [])
    return speeches_data
