import requests
from django.shortcuts import render

BASE_URL = "http://localhost:1337/api"


def fetch_all_pages(base_url, endpoint, params):
    all_results = []
    page = 1
    while True:
        params.update({"pagination[page]": page, "pagination[pageSize]": 25})
        response = requests.get(f"{base_url}/{endpoint}", params=params)
        if response.status_code != 200:
            break
        data = response.json().get("data", [])
        if not data:
            break
        all_results.extend(data)
        page += 1
    return all_results


def search_page(request):
    query = request.GET.get("query", "")
    query = query.upper()
    speakers = []
    debates = []

    if query:
        speaker_params = {"filters[name][$containsi]": query}
        speakers = fetch_all_pages(BASE_URL, "Speakers", speaker_params)
        debate_params = {"filters[debate_title][$containsi]": query}
        speeches = fetch_all_pages(BASE_URL, "Speeches", debate_params)

        debate_titles = set()
        for speech in speeches:
            title = speech["debate_title"]
            if title not in debate_titles:
                debate_titles.add(title)
                debates.append({
                    "debate_title": title,
                })
    return render(request, "parliament/search_page.html", {"speakers": speakers, "debates": debates, "query": query})


def debate_detail(request, debate_title):
    speech_params = {"filters[debate_title][$eq]": debate_title, "sort": "id"}
    speeches = fetch_all_pages(BASE_URL, "Speeches", speech_params)
    speaker_data = fetch_all_pages(BASE_URL, "Speakers", {})
    speaker_map = {speaker["name"]: speaker for speaker in speaker_data}

    for speech in speeches:
        speech["speaker_details"] = speaker_map.get(
            speech["speaker"], {})

    return render(request, "parliament/debate_detail.html", {"speeches": speeches})


def speaker_detail(request, name):
    speaker_params = {"filters[name][$eq]": name}
    speaker_data = fetch_all_pages(BASE_URL, "Speakers", speaker_params)
    speaker = speaker_data[0] if speaker_data else {}
    speech_params = {"filters[speaker][$eq]": name}
    speeches = fetch_all_pages(BASE_URL, "Speeches", speech_params)

    return render(request, "parliament/speaker_detail.html", {"speaker": speaker, "speeches": speeches})
