/**
 * speaker controller
 */

import { factories } from '@strapi/strapi'

export default factories.createCoreController('api::speaker.speaker');
